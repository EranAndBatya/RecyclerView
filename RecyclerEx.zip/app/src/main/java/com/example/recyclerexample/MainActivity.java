package com.example.recyclerexample;





import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private RecyclerView m_recycleView;
    private RecyclerView.LayoutManager m_LayoutManager;
    private List<String> m_list;
    private RecyclerAdapter m_adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m_recycleView=findViewById(R.id.recyclerView);
        m_LayoutManager=new LinearLayoutManager(this);
        m_recycleView.setLayoutManager(m_LayoutManager);
        m_list= Arrays.asList(getResources().getStringArray(R.array.android_versions));
        m_adapter= new RecyclerAdapter(m_list);
        m_recycleView.setHasFixedSize(true);
        m_recycleView.setAdapter(m_adapter);

    }
}
